# Lumora AI replacement starter

## Files
- `server.js`: AI chat, optional Google Custom Search, optional image generation.
- `public/index.html`: mobile-friendly chat interface.
- `package.json`: Node.js start configuration.

## Render settings
- Build command: `npm install`
- Start command: `npm start`

## Environment variables
Required for chat:
- `GROQ_API_KEY` = your Groq API key
- `GROQ_MODEL` = optional; defaults to `llama-3.3-70b-versatile`

Optional Google search:
- `GOOGLE_API_KEY` = Google Custom Search API key
- `GOOGLE_CSE_ID` = Programmable Search Engine ID

Optional image generation:
- `OPENAI_API_KEY` = OpenAI API key with image API access
- `OPENAI_IMAGE_MODEL` = optional; defaults to `gpt-image-1`

Never put secret API keys in `public/index.html` or commit them to GitHub.
Google Search and image generation can incur costs or quota limits.
