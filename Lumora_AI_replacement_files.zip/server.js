const express = require("express");
const path = require("path");

const app = express();
app.use(express.json({ limit: "2mb" }));
app.use(express.static(path.join(__dirname, "public")));

const PORT = process.env.PORT || 3000;

const SYSTEM_PROMPT = `
You are Lumora AI, a helpful, quick, multilingual assistant created by John Theuri.
Answer the user's actual latest question directly. NEVER repeat your introduction unless the user asks who you are.
Use the conversation history to understand follow-up questions.
Be friendly, clear, and concise by default. Expand when the user asks for detail.
Reply in the language the user uses where practical, including English and Swahili.
Do not claim you searched the web unless search results were actually provided.
When web results are provided, use them carefully and include source links in your answer.
Do not invent facts, school locations, prices, or current events. If information is uncertain, say so.
For requests to create an image, use the image generation endpoint when available.
`;

async function googleSearch(query) {
  const apiKey = process.env.GOOGLE_API_KEY;
  const cx = process.env.GOOGLE_CSE_ID;
  if (!apiKey || !cx) return null;

  const url = new URL("https://www.googleapis.com/customsearch/v1");
  url.searchParams.set("key", apiKey);
  url.searchParams.set("cx", cx);
  url.searchParams.set("q", query);
  url.searchParams.set("num", "5");

  const response = await fetch(url);
  const data = await response.json();
  if (!response.ok) {
    console.error("Google Search API error:", data.error?.message || response.status);
    return null;
  }

  return (data.items || []).map((item) => ({
    title: item.title,
    link: item.link,
    snippet: item.snippet
  }));
}

function needsWebSearch(message) {
  return /where is|location of|latest|today|current|news|price of|cost of|weather|who is|when is|this year|2026|search the web|look up|find online|school|hospital|near me|distance to/i.test(message);
}

function asksForImage(message) {
  return /generate (an? )?image|create (an? )?image|make (an? )?image|draw (me )?|generate a picture|create a picture|make a picture|design (a )?logo|create (a )?logo|generate (a )?logo/i.test(message);
}

async function chatWithGroq(messages) {
  if (!process.env.GROQ_API_KEY) {
    throw new Error("The server is missing GROQ_API_KEY. Add it in your hosting environment variables.");
  }

  const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${process.env.GROQ_API_KEY}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: process.env.GROQ_MODEL || "llama-3.3-70b-versatile",
      messages,
      temperature: 0.5,
      max_tokens: 900
    })
  });

  const data = await response.json();
  if (!response.ok) {
    console.error("Groq API error:", data.error?.message || response.status);
    throw new Error(data.error?.message || "AI provider request failed.");
  }
  return data.choices?.[0]?.message?.content || "Sorry, I couldn't produce an answer. Please try again.";
}

async function generateImage(prompt) {
  if (!process.env.OPENAI_API_KEY) {
    return {
      error: "Image generation is not configured yet. Add OPENAI_API_KEY in your hosting environment variables to enable it."
    };
  }

  const response = await fetch("https://api.openai.com/v1/images/generations", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: process.env.OPENAI_IMAGE_MODEL || "gpt-image-1",
      prompt,
      size: "1024x1024",
      quality: "high"
    })
  });

  const data = await response.json();
  if (!response.ok) {
    console.error("Image API error:", data.error?.message || response.status);
    return { error: data.error?.message || "Image generation failed. Check the image API account and billing." };
  }

  const imageData = data.data?.[0]?.b64_json;
  if (!imageData) return { error: "The image service returned no image. Please try again." };
  return { image: `data:image/png;base64,${imageData}` };
}

app.get("/api/health", (_req, res) => {
  res.json({
    ok: true,
    service: "Lumora AI",
    webSearchConfigured: Boolean(process.env.GOOGLE_API_KEY && process.env.GOOGLE_CSE_ID),
    imageGenerationConfigured: Boolean(process.env.OPENAI_API_KEY)
  });
});

app.post("/api/chat", async (req, res) => {
  try {
    const message = String(req.body?.message || "").trim();
    if (!message) return res.status(400).json({ error: "Please type a message first." });
    if (message.length > 6000) return res.status(400).json({ error: "Please keep your message under 6,000 characters." });

    if (asksForImage(message)) {
      const result = await generateImage(message);
      if (result.error) return res.json({ reply: result.error });
      return res.json({ reply: "Here is the image I generated for you.", image: result.image });
    }

    let searchResults = null;
    if (needsWebSearch(message)) {
      searchResults = await googleSearch(message);
    }

    const history = Array.isArray(req.body?.history) ? req.body.history : [];
    const safeHistory = history
      .filter((item) => item && ["user", "assistant"].includes(item.role) && typeof item.content === "string")
      .slice(-10)
      .map((item) => ({ role: item.role, content: item.content.slice(0, 3000) }));

    let userContent = message;
    if (searchResults?.length) {
      userContent += "\n\nVerified web search results (use only as supporting sources; link to relevant results):\n" +
        searchResults.map((r, i) => `${i + 1}. ${r.title}\n${r.snippet}\nSource: ${r.link}`).join("\n\n");
    } else if (needsWebSearch(message)) {
      userContent += "\n\nLive Google Search results were unavailable or not configured. Do not pretend that a web search succeeded. Answer cautiously and ask for a location or clarification if needed.";
    }

    const messages = [
      { role: "system", content: SYSTEM_PROMPT },
      ...safeHistory,
      { role: "user", content: userContent }
    ];

    const reply = await chatWithGroq(messages);
    res.json({
      reply,
      sources: searchResults?.length ? searchResults.map(({ title, link }) => ({ title, link })) : []
    });
  } catch (error) {
    console.error("Chat error:", error.message);
    res.status(500).json({ error: "Lumora couldn't answer right now. Please try again in a moment." });
  }
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Lumora AI server listening on port ${PORT}`);
});
